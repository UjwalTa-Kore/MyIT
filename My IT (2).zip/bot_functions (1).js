// private property
var _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function _utf8_encode(string) {
    string = string.replace(/\r\n/g,"\n");
    var utftext = "";

    for (var n = 0; n < string.length; n++) {

        var c = string.charCodeAt(n);

        if (c < 128) {
            utftext += String.fromCharCode(c);
        }
        else if((c > 127) && (c < 2048)) {
            utftext += String.fromCharCode((c >> 6) | 192);
            utftext += String.fromCharCode((c & 63) | 128);
        }
        else {
            utftext += String.fromCharCode((c >> 12) | 224);
            utftext += String.fromCharCode(((c >> 6) & 63) | 128);
            utftext += String.fromCharCode((c & 63) | 128);
        }

    }

    return utftext;
}

// public method for encoding
function encode(input) {
    var output = "";
    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
    var i = 0;

    input = _utf8_encode(input);

    while (i < input.length) {

        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);

        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;

        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        } else if (isNaN(chr3)) {
            enc4 = 64;
        }

        output = output +
        _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
        _keyStr.charAt(enc3) + _keyStr.charAt(enc4);

    }

    return output;
}

var authKeys = {
	"pattabhi.dasari@kore.com":"Basic cGF0dGFiaGk6S29yZUAxMjM=",
	"prasanna@kore.com":"Basic cHJhc2FubmE6S29yZUAxMjM=",
	"thirupathi.bandam@kore.com":"Basic dGhpcnU6S29yZUAxMjM="
};

var state_map = {
	"1":"New",
	"2":"In Progress",
	"3":"On Hold",
	"6":"Resolved",
	"7":"Closed",
	"8":"Cancelled"
}

var message_map = {
	"ViewTicketStatus.IncidentId":"Please provide incident id if you are looking for the status of a different incident",
	"ReopenTicket.IncidentId": "Please provide id of incident to reopen",

}

function getAuthKey(email){
	return authKeys[email] || authKeys["thirupathi.bandam@kore.com"]
}

var authKey = authKeys[context.session.UserContext.emailId];



function isIntentDisabled(intentName) {
    var contentValue = content["IntentEnableorDisable"];
    var contentJSON = JSON.parse(contentValue);
    
    if (contentJSON[intentName]) {
        return contentJSON[intentName];
    } else {
        return -1;
    }
        
}

function GetFormattedDate(date){
    var _date = new Date(date);
    var months = ["Jan","Feb","March","April","May","June","July","Aug","Sept","Oct","Nov","Dec"];
    return _date.getDate()+"-"+months[_date.getMonth()]+"-"+_date.getFullYear()
}

function CapitaliseFirstWord (sent) {
    //gets the first word the sentence
    return sent.replace(/(?<=^[\s"']*)(\w+)/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();})
}